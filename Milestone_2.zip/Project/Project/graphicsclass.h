////////////////////////////////////////////////////////////////////////////////
// Filename: graphicsclass.h
////////////////////////////////////////////////////////////////////////////////
#ifndef _GRAPHICSCLASS_H_
#define _GRAPHICSCLASS_H_


///////////////////////
// MY CLASS INCLUDES //
///////////////////////
#include "d3dclass.h"
#include "cameraclass.h"
#include "modelclass.h"
#include "ambientLightShaderClass.h"
#include "specularlightshaderclass.h"
#include "lightclass.h"
#include "bitmapclass.h"
#include "textureshaderclass.h"
#include "textclass.h"
#include "modellistclass.h"
#include "frustumclass.h"

/////////////
// GLOBALS //
/////////////
const bool FULL_SCREEN = true;
const bool VSYNC_ENABLED = true;
const float SCREEN_DEPTH = 1000.0f;
const float SCREEN_NEAR = 0.1f;


////////////////////////////////////////////////////////////////////////////////
// Class name: GraphicsClass
////////////////////////////////////////////////////////////////////////////////
class GraphicsClass
{
public:
	GraphicsClass();
	GraphicsClass(const GraphicsClass&);
	~GraphicsClass();

	bool Initialize(int, int, HWND);
	void Shutdown();
	bool Frame(int, int, float, int, int, D3DXVECTOR3, D3DXVECTOR3, unsigned int);
	bool Render();

private:
	D3DClass * m_D3D;
	CameraClass* m_Camera;
	AmbientLightShaderClass* m_ambientLightShader;
	SpecularLightShaderClass* m_specularLightShader;
	TextureShaderClass* m_textureShader;
	LightClass* m_Light;
	BitmapClass* m_Bitmap;
	TextClass* m_Text;

	ModelListClass* m_ModelList;
	vector<const char*> filenameList;
	vector<const WCHAR*> textureList;

	ModelClass* m_skyboxModel;

	FrustumClass* m_Frustum;

	DWORD g_tNow, g_tPre;
	unsigned int numFont;

	LightClass *m_Light1, *m_Light2, *m_Light3, *m_Light4;
	D3DXVECTOR3 pointLightPos[4];
};

#endif