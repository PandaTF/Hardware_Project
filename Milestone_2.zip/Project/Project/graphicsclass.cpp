////////////////////////////////////////////////////////////////////////////////
// Filename: graphicsclass.cpp
////////////////////////////////////////////////////////////////////////////////
#include "graphicsclass.h"


GraphicsClass::GraphicsClass()
{
	m_D3D = 0;
	m_Camera = 0;
	m_skyboxModel = 0;
	m_ambientLightShader = 0;
	m_specularLightShader = 0;
	m_textureShader = 0;
	m_Light = 0;

	m_Bitmap = 0;
	m_Text = 0;

	m_ModelList = 0;
	m_Frustum = 0;

	m_Light1 = 0;
	m_Light2 = 0;
	m_Light3 = 0;
	m_Light4 = 0;
}


GraphicsClass::GraphicsClass(const GraphicsClass& other)
{
}


GraphicsClass::~GraphicsClass()
{
}


bool GraphicsClass::Initialize(int screenWidth, int screenHeight, HWND hwnd)
{
	bool result;
	D3DXMATRIX baseViewMatrix;


	// Create the Direct3D object.
	m_D3D = new D3DClass;
	if (!m_D3D)
	{
		return false;
	}

	// Initialize the Direct3D object.
	result = m_D3D->Initialize(screenWidth, screenHeight, VSYNC_ENABLED, hwnd, FULL_SCREEN, SCREEN_DEPTH, SCREEN_NEAR);
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize Direct3D.", L"Error", MB_OK);
		return false;
	}

	// Create the camera object.
	m_Camera = new CameraClass;
	if (!m_Camera)
	{
		return false;
	}

	// Set the initial position of the camera.
	m_Camera->SetPosition(0.0f, 0.0f, -10.0f);
	m_Camera->Render();
	m_Camera->RenderBitmap();
	m_Camera->GetBitmapViewMatrix(baseViewMatrix);

	// Create the model object.
	m_skyboxModel = new ModelClass;
	if (!m_skyboxModel)
	{
		return false;
	}

	// Create the light shader object.
	m_specularLightShader = new SpecularLightShaderClass;
	if (!m_specularLightShader)
	{
		return false;
	}

	// Initialize the light shader object.
	result = m_specularLightShader->Initialize(m_D3D->GetDevice(), hwnd);
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the specular light shader object.", L"Error", MB_OK);
		return false;
	}

	m_ambientLightShader = new AmbientLightShaderClass;
	if (!m_ambientLightShader)
	{
		return false;
	}

	result = m_ambientLightShader->Initialize(m_D3D->GetDevice(), hwnd);
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the ambient light shader object.", L"Error", MB_OK);
		return false;
	}

	// Create the light object.
	m_Light = new LightClass;
	if (!m_Light)
	{
		return false;
	}

	// Create the texture shader object.
	m_textureShader = new TextureShaderClass;
	if(!m_textureShader)
	{
		return false;
	}

	// Initialize the texture shader object.
	result = m_textureShader->Initialize(m_D3D->GetDevice(), hwnd);
	if(!result)
	{
		MessageBox(hwnd, L"Could not initialize the texture shader object.", L"Error", MB_OK);
		return false;
	}

	// Create the bitmap object.
	m_Bitmap = new BitmapClass;
	if (!m_Bitmap)
	{
		return false;
	}

	// Initialize the bitmap object.
	result = m_Bitmap->Initialize(m_D3D->GetDevice(), screenWidth, screenHeight, L"../Project/data/ship.dds", 256, 256);
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the bitmap object.", L"Error", MB_OK);
		return false;
	}

	// Create the text object.
	m_Text = new TextClass;
	if (!m_Text)
	{
		return false;
	}

	numFont = 5;

	// Initialize the text object.
	result = m_Text->Initialize(m_D3D->GetDevice(), m_D3D->GetDeviceContext(), hwnd, screenWidth, screenHeight, baseViewMatrix, numFont);
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the text object.", L"Error", MB_OK);
		return false;
	}

	int tempY = 20;
	for (unsigned int i = 0; i < numFont; i++)
	{
		string tempStr = "Default";
		m_Text->updateSentenceWithIndex(m_D3D->GetDeviceContext(), i, (tempStr + to_string(i)).c_str(), 20, tempY, D3DXVECTOR3(1.0f, 1.0f, 1.0f));
		tempY += 20;
	}



	// Initialize the model list
	const char* filename = "../Project/data/ship.txt";
	const WCHAR* textureName = L"../Project/data/ship.dds";
	filenameList.push_back(filename);
	textureList.push_back(textureName);

	m_ModelList = new ModelListClass();
	if (!m_ModelList)
	{
		return false;
	}
	result = m_ModelList->Initialize(m_D3D->GetDevice(), filenameList, textureList, 1);
	if (!result)
	{
		return false;
	}

	// Initialize the skybox model object.
	result = m_skyboxModel->Initialize(m_D3D->GetDevice(), "../Project/data/skybox.txt", L"../Project/data/skybox.dds", true);
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	// Create the frustum object.
	m_Frustum = new FrustumClass;
	if (!m_Frustum)
	{
		return false;
	}

	// Create the first light object.
	m_Light1 = new LightClass;
	if (!m_Light1)
	{
		return false;
	}

	// Create the second light object.
	m_Light2 = new LightClass;
	if (!m_Light2)
	{
		return false;
	}

	// Create the third light object.
	m_Light3 = new LightClass;
	if (!m_Light3)
	{
		return false;
	}

	// Create the fourth light object.
	m_Light4 = new LightClass;
	if (!m_Light4)
	{
		return false;
	}

	// Initialize the light object.
	m_Light->SetAmbientColor(0.15f, 0.15f, 0.15f, 1.0f);
	m_Light->SetDiffuseColor(1.0f, 1.0f, 1.0f, 1.0f);
	m_Light->SetSpecularColor(1.0f, 1.0f, 1.0f, 1.0f);
	m_Light->SetSpecularPower(64.0f);


	pointLightPos[0] = D3DXVECTOR3(0.0f, 0.0, 0.0f);
	pointLightPos[1] = D3DXVECTOR3(10.0f, 0.0f, 0.0f);
	pointLightPos[2] = D3DXVECTOR3(-10.0f, 0.0f, 0.0f);
	pointLightPos[3] = D3DXVECTOR3(0.0f, 10.0f, -120.0f);

	// Initialize the first light object.
	m_Light1->SetPointLightColor(1.0f, 0.0f, 0.0f, 1.0f);
	m_Light1->SetPointLightPosition(pointLightPos[0].x, pointLightPos[0].y, pointLightPos[0].z);

	// Initialize the second light object.
	m_Light2->SetPointLightColor(0.0f, 0.0f, 1.0f, 1.0f);
	m_Light2->SetPointLightPosition(pointLightPos[1].x, pointLightPos[1].y, pointLightPos[1].z);

	// Initialize the third light object.
	m_Light3->SetPointLightColor(0.0f, 1.0f, 0.0f, 1.0f);
	m_Light3->SetPointLightPosition(pointLightPos[2].x, pointLightPos[2].y, pointLightPos[2].z);

	// Initialize the fourth light object.
	m_Light4->SetPointLightColor(1.0f, 1.0f, 1.0f, 1.0f);
	m_Light4->SetPointLightPosition(pointLightPos[3].x, pointLightPos[3].y, pointLightPos[3].z);

	g_tNow = g_tPre = 0;

	return true;
}


void GraphicsClass::Shutdown()
{
	// Release the light objects.
	if (m_Light1)
	{
		delete m_Light1;
		m_Light1 = 0;
	}

	if (m_Light2)
	{
		delete m_Light2;
		m_Light2 = 0;
	}

	if (m_Light3)
	{
		delete m_Light3;
		m_Light3 = 0;
	}

	if (m_Light4)
	{
		delete m_Light4;
		m_Light4 = 0;
	}

	// Release the bitmap object.
	if (m_Bitmap)
	{
		m_Bitmap->Shutdown();
		delete m_Bitmap;
		m_Bitmap = 0;
	}

	// Release the text object.
	if (m_Text)
	{
		m_Text->Shutdown();
		delete m_Text;
		m_Text = 0;
	}

	if (m_textureShader)
	{
		m_textureShader->Shutdown();
		delete m_textureShader;
		m_textureShader = 0;
	}

	// Release the light object.
	if(m_Light)
	{
		delete m_Light;
		m_Light = 0;
	}

	if (m_ambientLightShader)
	{
		m_ambientLightShader->Shutdown();
		delete m_ambientLightShader;
		m_ambientLightShader = 0;
	}

	// Release the light shader object.
	if(m_specularLightShader)
	{
		m_specularLightShader->Shutdown();
		delete m_specularLightShader;
		m_specularLightShader = 0;
	}

	// Release the model object.
	if(m_skyboxModel)
	{
		m_skyboxModel->Shutdown();
		delete m_skyboxModel;
		m_skyboxModel = 0;
	}

	// Release the camera object.
	if(m_Camera)
	{
		delete m_Camera;
		m_Camera = 0;
	}

	// Release the D3D object.
	if(m_D3D)
	{
		m_D3D->Shutdown();
		delete m_D3D;
		m_D3D = 0;
	}

	if (m_ModelList)
	{
		m_ModelList->Shutdown();
		delete m_ModelList;
		m_ModelList = 0;
	}

	// Release the frustum object.
	if (m_Frustum)
	{
		delete m_Frustum;
		m_Frustum = 0;
	}

	return;
}


bool GraphicsClass::Frame(int fps, int cpu, float frameTime, int mouseX, int mouseY, D3DXVECTOR3 position, D3DXVECTOR3 rotation, unsigned int LightType)
{
	bool result;
	static float deg = 0.0f;

	// Set the cpu usage.
	result = m_Text->SetCpu(cpu, m_D3D->GetDeviceContext(),0);
	if (!result)
	{
		return false;
	}

	// Set the frames per second.
	result = m_Text->SetFps(fps, m_D3D->GetDeviceContext(), 1);
	if (!result)
	{
		return false;
	}

	// Update the location of the mouse
	result = m_Text->UpdateMousePositionInfo(mouseX, mouseY, m_D3D->GetDeviceContext(), 2, 3);
	if (!result)
	{
		return false;
	}

	switch (LightType)
	{
	case 1: //Light On
		m_Light->SetAmbientColor(0.15f, 0.15f, 0.15f, 1.0f);
		m_Light->SetDiffuseColor(1.0f, 1.0f, 1.0f, 1.0f);
		m_Light->SetSpecularColor(1.0f, 1.0f, 1.0f, 1.0f);
		m_Light->SetSpecularPower(64.0f);

		m_Light1->SetPointLightColor(0.0f, 0.0f, 0.0f, 0.0f);
		m_Light2->SetPointLightColor(0.0f, 0.0f, 0.0f, 0.0f);
		m_Light3->SetPointLightColor(0.0f, 0.0f, 0.0f, 0.0f);
		m_Light4->SetPointLightColor(0.0f, 0.0f, 0.0f, 0.0f);

		deg += 0.005f;
		if (deg > 360.0f)
			deg -= 360.0f;

		m_Light->SetDirection(1 * cosf(deg), -0.4f, 1 * sinf(deg));
		break;

	case 2: //Light Off
		m_Light->SetAmbientColor(0.0f, 0.0f, 0.0f, 0.0f);
		m_Light->SetDiffuseColor(0.0f, 0.0f, 0.0f, 0.0f);
		m_Light->SetSpecularColor(0.0f, 0.0f, 0.0f, 0.0f);
		m_Light->SetSpecularPower(100000000000.0f);

		//PointLight 1 Red
		pointLightPos[0].x += 0.5f;
		if (pointLightPos[0].x > 100.0f)
			pointLightPos[0].x -= 200.0f;

		m_Light1->SetPointLightColor(1.0f, 0.0f, 0.0f, 1.0f);
		m_Light1->SetPointLightPosition(pointLightPos[0].x, pointLightPos[0].y, pointLightPos[0].z);

		//PointLight 2 Blue
		pointLightPos[1].z += 0.5f;
		if (pointLightPos[1].z > 100.0f)
			pointLightPos[1].z -= 200.0f;

		m_Light2->SetPointLightColor(0.0f, 0.0f, 1.0f, 1.0f);
		m_Light2->SetPointLightPosition(pointLightPos[1].x, pointLightPos[1].y, pointLightPos[1].z);

		//PointLight 3 Green
		pointLightPos[2].z -= 0.5f;
		if (pointLightPos[2].z < -100.0f)
			pointLightPos[2].z += 200.0f;

		m_Light3->SetPointLightColor(0.0f, 1.0f, 0.0f, 1.0f);
		m_Light3->SetPointLightPosition(pointLightPos[2].x, pointLightPos[2].y, pointLightPos[2].z);

		//PointLight 4 Yellow
		pointLightPos[3].y -= 0.5f;
		if (pointLightPos[3].y < -100.0f)
			pointLightPos[3].y += 200.0f;

		m_Light4->SetPointLightColor(1.0f, 1.0f, 1.0f, 1.0f);
		m_Light4->SetPointLightPosition(pointLightPos[3].x, pointLightPos[3].y, pointLightPos[3].z);
		break;
	case 3:
		break;
	}

	m_Camera->SetPosition(position.x, position.y, position.z);
	m_Camera->SetRotation(rotation.x, rotation.y, rotation.z);

	return true;
}


bool GraphicsClass::Render()
{
	D3DXMATRIX worldMatrix, viewMatrix, projectionMatrix, orthoMatrix;
	bool result;
	int renderCount, modelCount;

	D3DXMATRIX skyBoxMatrix;
	D3DXMATRIX bitmapMatrix, bitmapViewMatrix, fontMatrix, fontViewMatrix;

	static float degree = 0.0f;
	// Update the rotation variable each frame.
	degree += (float)D3DX_PI * 0.05f;
	if (degree > 360.0f)
	{
		degree -= 360.0f;
	}

	// Clear the buffers to begin the scene.
	m_D3D->BeginScene(0.1f, 0.1f, 0.1f, 1.0f);

	// Generate the view matrix based on the camera's position.
	m_Camera->Render();

	// Get the world, view, and projection matrices from the camera and d3d objects.
	m_Camera->GetViewMatrix(viewMatrix);
	m_D3D->GetWorldMatrix(worldMatrix);
	m_D3D->GetProjectionMatrix(projectionMatrix);

	m_D3D->GetOrthoMatrix(orthoMatrix);

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// Construct the frustum.
	m_Frustum->ConstructFrustum(SCREEN_DEPTH, projectionMatrix, viewMatrix);

	// Get the number of models
	modelCount = m_ModelList->GetNumOfModels();

	// Initialize the count of models that have been rendered.
	renderCount = 0;

	vector<ModelClass*> modelList;
	modelList = m_ModelList->GetModelList();

	//Models Info Update
	m_ModelList->SetModelRadius(0, 100.0f);
	m_ModelList->SetModelScaling(0, 0.05f, 0.05f, 0.05f);
	m_ModelList->SetModelRotation(0, 0.0f, 0.0f, 0.0f);

	// Go through all the models and render them only if they can be seen by the camera view.
	for (int index = 0; index<modelCount; index++)
	{
		D3DXVECTOR3 position = m_ModelList->GetModelPosition(index);
		float radius = m_ModelList->GetmodelRadius(index);

		// Check if the sphere model is in the view frustum.
		result = m_Frustum->CheckSphere(position.x, position.y, position.z, radius);

		if (result)
		{
			D3DXVECTOR4 pointLightColor[4];
			D3DXVECTOR4 pointLightPosition[4];

			D3DXVECTOR3 rotation = m_ModelList->GetModelRotation(index);
			D3DXVECTOR3 scaling = m_ModelList->GetModelScaling(index);

			D3DXMATRIX thisWorldMatrix = m_ModelList->GetModelWorldMatrix(index);
			D3DXMATRIX t, r, s;

			D3DXMatrixMultiply(&thisWorldMatrix, &thisWorldMatrix, &worldMatrix);

			//T
			D3DXMatrixTranslation(&t, position.x, position.y, position.z);
			D3DXMatrixMultiply(&thisWorldMatrix, &thisWorldMatrix, &t);

			//R
			D3DXMatrixRotationYawPitchRoll(&r, D3DXToRadian(rotation.y), D3DXToRadian(rotation.x), D3DXToRadian(rotation.z));
			D3DXMatrixMultiply(&thisWorldMatrix, &thisWorldMatrix, &r);

			//S
			D3DXMatrixScaling(&s, scaling.x, scaling.y, scaling.z);
			D3DXMatrixMultiply(&thisWorldMatrix, &thisWorldMatrix, &s);

			modelList[index]->Render(m_D3D->GetDeviceContext());

			
			// Render the model using the specular light shader.
			// Create the diffuse color array from the four light colors.
			pointLightColor[0] = m_Light1->GetPointLightColor();
			pointLightColor[1] = m_Light2->GetPointLightColor();
			pointLightColor[2] = m_Light3->GetPointLightColor();
			pointLightColor[3] = m_Light4->GetPointLightColor();

			// Create the light position array from the four light positions.
			pointLightPosition[0] = m_Light1->GetPointLightPosition();
			pointLightPosition[1] = m_Light2->GetPointLightPosition();
			pointLightPosition[2] = m_Light3->GetPointLightPosition();
			pointLightPosition[3] = m_Light4->GetPointLightPosition();

			result = m_specularLightShader->Render(m_D3D->GetDeviceContext(), modelList[index]->GetIndexCount(), 
				thisWorldMatrix, viewMatrix, projectionMatrix,
				modelList[index]->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(),
				m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower(),pointLightColor, pointLightPosition);

			if (!result)
			{
				return false;
			}

			renderCount++;
		}
	}

	//Sky Box
	m_Light->SetDiffuseColor(0.0f, 0.0f, 0.0f, 1.0f);
	m_Light->SetAmbientColor(1.0f, 1.0f, 1.0f, 1.0f);

	m_D3D->GetWorldMatrix(skyBoxMatrix);
	m_skyboxModel->Render(m_D3D->GetDeviceContext());

	D3DXMATRIX skyBoxR, skyBoxT, skyBoxS;

	D3DXMatrixIdentity(&skyBoxS);
	D3DXMatrixScaling(&skyBoxS, SCREEN_DEPTH, SCREEN_DEPTH, SCREEN_DEPTH);
	D3DXMatrixMultiply(&skyBoxMatrix, &skyBoxMatrix, &skyBoxS);
	float cX, cY, cZ;
	cX = m_Camera->GetPosition().x;
	cY = m_Camera->GetPosition().y;
	cZ = m_Camera->GetPosition().z;
	D3DXMatrixTranslation(&skyBoxT, cX, cY, cZ);
	D3DXMatrixMultiply(&skyBoxMatrix, &skyBoxMatrix, &skyBoxT);

	result = m_ambientLightShader->Render(m_D3D->GetDeviceContext(), m_skyboxModel->GetIndexCount(), skyBoxMatrix, viewMatrix, projectionMatrix,
		m_skyboxModel->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor());

	m_Light->SetDiffuseColor(1.0f, 1.0f, 1.0f, 1.0f);
	m_Light->SetAmbientColor(0.15f, 0.15f, 0.15f, 1.0f);

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	m_Camera->RenderBitmap();
	m_Camera->GetBitmapViewMatrix(bitmapViewMatrix);
	m_D3D->GetWorldMatrix(bitmapMatrix);

	// Turn off the Z buffer to begin all 2D rendering.
	m_D3D->TurnZBufferOff();

	// Put the bitmap vertex and index buffers on the graphics pipeline to prepare them for drawing.
	result = m_Bitmap->Render(m_D3D->GetDeviceContext(), 50, 900, 100, 100);
	if (!result)
	{
		return false;
	}

	//D3DXMatrixMultiply(&bitmapMatrix, &bitmapMatrix, &worldMatrix);
	// Render the bitmap with the texture shader.
	result = m_textureShader->Render(m_D3D->GetDeviceContext(), m_Bitmap->GetIndexCount(), bitmapMatrix, 
		bitmapViewMatrix, orthoMatrix, m_Bitmap->GetTexture());
	if (!result)
	{
		return false;
	}

	m_Camera->GetBitmapViewMatrix(fontViewMatrix);
	m_D3D->GetWorldMatrix(fontMatrix);

	// Turn on the alpha blending before rendering the text.
	m_D3D->TurnOnAlphaBlending();

	//D3DXMatrixMultiply(&fontMatrix, &fontMatrix, &worldMatrix);

	//int posX = m_Text->GetFontPositionX(1);
	//int posY = m_Text->GetFontPositionY(1);
	//D3DXVECTOR3 color = m_Text->GetFontColor(1);
	//string newSentence = "Sentence";
	////
	////result = m_Text->updateSentenceWithIndex(m_D3D->GetDeviceContext(), 1, (newSentence+" 1").c_str(), posX, posY, color);
	//result = m_Text->updateSentenceWithIndex(m_D3D->GetDeviceContext(), 2, (newSentence+" 2").c_str(), posX, posY+20, color);

	// Render the text strings.
	result = m_Text->Render(m_D3D->GetDeviceContext(), fontViewMatrix, orthoMatrix);
	if (!result)
	{
		return false;
	}

	// Turn off alpha blending after rendering the text.
	m_D3D->TurnOffAlphaBlending();

	// Turn the Z buffer back on now that all 2D rendering has completed.
	m_D3D->TurnZBufferOn();

	// Present the rendered scene to the screen.
	m_D3D->EndScene();

	return true;
}