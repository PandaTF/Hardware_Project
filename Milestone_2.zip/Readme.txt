Button List:
Up Arrow 		- Moving forward
Down Arrow 	- Moving backward
Left Arrow	- Turn left
Right Arrow	- Turn right
Page Up		- Look up
Page Down	- Look down
Space		- Moving Up
Left Ctrl		- Moving down
1		- Turn on specular Light test
2		- Turn on point light test 
ESC		- Exist Program